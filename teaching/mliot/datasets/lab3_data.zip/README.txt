Lab 3 dataset — 2026-10-15, 2 training / 3 hidden per new class
Six raw channels at 100 Hz: acceleration m/s^2 including gravity, gyroscope deg/s; no magnetometer.
training/: 99 recordings, including 2 new circle and 2 new snake recordings.
testing/: 24 original public validation recordings, not leaderboard hidden data.
Three additional recordings per new class are reserved as hidden tests and excluded from this archive. Live and final scoring use the same hidden set.
